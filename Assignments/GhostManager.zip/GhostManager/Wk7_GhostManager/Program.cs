﻿
using var game = new Wk7_GhostManager.Game1();
game.Run();
