﻿//Nehemiah Cedillo
//Game Programming I SP24
//SP24-PROG 310-01
//January 28, 2024

//Credits:
// Jeff Meyers:
// Provided course materials and lectures.

using var game = new Monogame_Picture.Game1();
game.Run();
