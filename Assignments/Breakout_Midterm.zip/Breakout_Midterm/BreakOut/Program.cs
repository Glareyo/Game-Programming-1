﻿
using var game = new BreakOut.Game1();
game.Run();
