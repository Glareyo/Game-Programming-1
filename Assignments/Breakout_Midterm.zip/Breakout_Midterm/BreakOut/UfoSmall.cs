﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BreakOut
{
    public class UfoSmall : Invader
    {
        public UfoSmall(Game game) : base(game)
        { 
        }
    }
}
